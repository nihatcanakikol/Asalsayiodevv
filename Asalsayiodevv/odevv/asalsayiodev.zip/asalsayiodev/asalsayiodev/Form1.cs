namespace asalsayiodev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          int a = Convert.ToInt32(textBox1.Text);
            if(a==2 || a==3 || a==5 || a==7)
            {
                listBox1.Items.Add(a);
            }
            int b = Convert.ToInt32(textBox2.Text);
            if (b == 2 || b == 3 || b == 5 || b == 7)
            {
                listBox1.Items.Add(b);
            }
            int c = Convert.ToInt32(textBox3.Text);
            if (c == 2 || c == 3 || c == 5 || c == 7)
            {
                listBox1.Items.Add(c);
            }
            int d = Convert.ToInt32(textBox4.Text);
            if (d == 2 || d == 3 || d == 5 || d == 7)
            {
                listBox1.Items.Add(d);
            }
            int z = Convert.ToInt32(textBox5.Text);
            if (z == 2 || z == 3 || z == 5 || z == 7)
            {
                listBox1.Items.Add(z);
            }
            int f = Convert.ToInt32(textBox6.Text);
            if (f == 2 || f == 3 || f == 5 || f == 7)
            {
                listBox1.Items.Add(f);
            }
            int g = Convert.ToInt32(textBox7.Text);
            if (g == 2 || g == 3 || g == 5 || g == 7)
            {
                listBox1.Items.Add(g);
            }
            int h = Convert.ToInt32(textBox8.Text);
            if (h == 2 || h == 3 || h == 5 || h == 7)
            {
                listBox1.Items.Add(h);
            }
            int i = Convert.ToInt32(textBox9.Text);
            if (i == 2 || i == 3 || i == 5 || i == 7)
            {
                listBox1.Items.Add(i);
            }
            int j = Convert.ToInt32(textBox10.Text);
            if (j == 2 || j == 3 || j == 5 || j == 7)
            {
                listBox1.Items.Add(j);
            }
            int k = Convert.ToInt32(textBox11.Text);
            if (k == 2 || k == 3 || k == 5 || k == 7)
            {
                listBox1.Items.Add(k);
            }
        }

        
        private void textBox11_TextChanged(object sender, EventArgs e)
        {
          
          

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}